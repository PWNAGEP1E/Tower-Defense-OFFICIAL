//
//  Tile.swift
//  Cookie Crunch
//
//  Created by jeremy on 3/7/16.
//  Copyright © 2016 Indicane. All rights reserved.
//

import Foundation


class Tile {
}